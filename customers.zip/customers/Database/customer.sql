-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2017 at 12:51 PM
-- Server version: 5.6.31
-- PHP Version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer`
--

-- --------------------------------------------------------

--
-- Table structure for table `Agent`
--

CREATE TABLE IF NOT EXISTS `Agent` (
  `idAgent` int(11) NOT NULL,
  `idNumber` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Agent`
--

INSERT INTO `Agent` (`idAgent`, `idNumber`, `status`, `User_idUser`) VALUES
(1, '343-4345', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Buy`
--

CREATE TABLE IF NOT EXISTS `Buy` (
  `idBuy` int(11) NOT NULL,
  `buyTime` datetime DEFAULT NULL,
  `amountPaid` varchar(45) DEFAULT NULL,
  `Currency_idCurrency` int(11) NOT NULL,
  `Customer_idCustomer` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChangeRate`
--

CREATE TABLE IF NOT EXISTS `ChangeRate` (
  `idChangeRate` int(11) NOT NULL,
  `Currency_idCurrency` int(11) NOT NULL,
  `value` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Conversation`
--

CREATE TABLE IF NOT EXISTS `Conversation` (
  `idConversation` int(11) NOT NULL,
  `conversationName` varchar(45) DEFAULT NULL,
  `openingDate` datetime DEFAULT NULL,
  `Tickets_idTickets` int(11) NOT NULL,
  `Tickets_Customer_idCustomer` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Conversation`
--

INSERT INTO `Conversation` (`idConversation`, `conversationName`, `openingDate`, `Tickets_idTickets`, `Tickets_Customer_idCustomer`) VALUES
(1, 'Ticket_10000', '2017-05-03 00:22:36', 1, 1),
(2, 'Ticket_40000', '2017-05-03 01:08:30', 4, 1),
(3, 'Ticket_30000', '2017-05-03 01:18:20', 3, 1),
(4, 'Ticket_50000', '2017-05-03 10:15:46', 5, 1),
(5, 'Ticket_60000', '2017-05-03 11:52:07', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Currency`
--

CREATE TABLE IF NOT EXISTS `Currency` (
  `idCurrency` int(11) NOT NULL,
  `currencyName` varchar(45) DEFAULT NULL,
  `currencySymbol` varchar(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE IF NOT EXISTS `Customer` (
  `idCustomer` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` (`idCustomer`, `status`, `User_idUser`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Message`
--

CREATE TABLE IF NOT EXISTS `Message` (
  `idMessage` int(11) NOT NULL,
  `content` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `Conversation_idConversation` int(11) NOT NULL,
  `senderId` int(11) DEFAULT NULL COMMENT 'The ID of the message\nsender.\nIt can be the custo\nmer or the agent',
  `senderType` int(11) DEFAULT NULL COMMENT '1 - customer\n2 - agent\n'
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Message`
--

INSERT INTO `Message` (`idMessage`, `content`, `status`, `creationDate`, `Conversation_idConversation`, `senderId`, `senderType`) VALUES
(1, 'C\\''est bon mon boss. Je kiff', 1, '2017-05-03 00:50:45', 1, 1, 1),
(2, 'Hello boss', 1, '2017-05-03 01:12:41', 1, 1, 1),
(3, 'Cool, man', 1, '2017-05-03 01:14:04', 2, 1, 1),
(4, 'La force du ble, parce que la vie n\\''a pas de', 1, '2017-05-03 01:18:35', 3, 1, 1),
(5, 'Hi', 1, '2017-05-03 01:40:40', 2, 1, 1),
(6, 'Ca c\\''est excellent, j\\''aimerai avoir des pre', 2, '2017-05-03 01:41:01', 2, 1, 1),
(7, 'Hello', 1, '2017-05-03 02:03:46', 2, 1, 1),
(8, 'Cool', 1, '2017-05-03 02:04:09', 2, 1, 1),
(9, 'Nalingi yo!', 1, '2017-05-03 02:04:15', 2, 1, 1),
(10, 'Thank you very much sir', 1, '2017-05-03 02:04:24', 2, 1, 2),
(11, 'No', 1, '2017-05-03 02:04:42', 3, 1, 1),
(12, 'i am looking for Mathe Eliel on This project,', 1, '2017-05-03 02:09:50', 2, 1, 1),
(13, 'Hi', 1, '2017-05-03 02:11:45', 2, 1, 1),
(14, 'De ta niche', 1, '2017-05-03 02:11:54', 2, 1, 1),
(15, 'Honte', 1, '2017-05-03 02:12:29', 2, 1, 1),
(16, 'Hi', 1, '2017-05-03 10:21:45', 4, 2, 2),
(17, 'Nous allons voir comment vous aider dans les ', 1, '2017-05-03 10:22:38', 4, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `ReadBy`
--

CREATE TABLE IF NOT EXISTS `ReadBy` (
  `idReadBy` int(11) NOT NULL,
  `dateRead` datetime DEFAULT NULL,
  `Agent_idAgent` int(11) NOT NULL,
  `Message_idMessage` int(11) NOT NULL,
  `Message_Conversation_idConversation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Service`
--

CREATE TABLE IF NOT EXISTS `Service` (
  `idService` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `ServicePricing_idServicePricing` int(11) NOT NULL,
  `ServicePricing_Currency_idCurrency` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ServicePricing`
--

CREATE TABLE IF NOT EXISTS `ServicePricing` (
  `idServicePricing` int(11) NOT NULL,
  `amount` float DEFAULT NULL,
  `reduction` float DEFAULT NULL,
  `additionTime` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `Currency_idCurrency` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TicketAttachedFiles`
--

CREATE TABLE IF NOT EXISTS `TicketAttachedFiles` (
  `idTicketFiles` int(11) NOT NULL,
  `fileLink` varchar(255) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `Tickets_idTickets` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TicketOfType`
--

CREATE TABLE IF NOT EXISTS `TicketOfType` (
  `idTicketOfType` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `TicketType_idTicketType` int(11) NOT NULL,
  `Tickets_idTickets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Tickets`
--

CREATE TABLE IF NOT EXISTS `Tickets` (
  `idTickets` int(11) NOT NULL,
  `content` text,
  `openingDate` datetime DEFAULT NULL,
  `closingDate` datetime DEFAULT NULL,
  `priority` int(11) DEFAULT NULL COMMENT 'Urgent\n',
  `required_service` int(11) DEFAULT NULL COMMENT 'Sales\nTechnical',
  `status` int(11) DEFAULT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  `solution` text,
  `problem_discovered` text,
  `solution_by_id_user_agent` int(11) DEFAULT NULL,
  `reason_closing` text
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Tickets`
--

INSERT INTO `Tickets` (`idTickets`, `content`, `openingDate`, `closingDate`, `priority`, `required_service`, `status`, `Customer_idCustomer`, `solution`, `problem_discovered`, `solution_by_id_user_agent`, `reason_closing`) VALUES
(1, 'Problem on installation of new services', '2017-05-01 18:20:34', NULL, 0, 0, 3, 1, NULL, NULL, NULL, NULL),
(2, 'Hello world, I am just trying to use this', '2017-05-01 18:26:55', NULL, 1, 2, 3, 1, NULL, NULL, NULL, 'We saw that this is no more an issue'),
(3, 'B\r\nuttons were explained in chapter Bootstrap Buttons. With this plugin you can add in some interaction\r\nsuch as control button states or create groups of buttons for more components like toolbars.\r\nIf you want to include this plugin functionality individually, then you will need button.js. Else, as mentioned in the\r\nchapter Bootstrap Plugins Overview, you can include bootstrap.js or the minified bootstrap.min.js.\r\nLoading State\r\nTo add a loading state to a button, simply add data-loading-text="Loading..." as an attribute to the button\r\nelement as shown in the following example:', '2017-05-01 18:56:53', NULL, 3, 1, 3, 1, NULL, NULL, NULL, 'Okay, we are going to prepare this in two days, just be patient'),
(4, 'I have a problem on a descent work. Please, go and talk to people.', '2017-05-01 20:05:05', NULL, 2, 1, 3, 1, NULL, NULL, NULL, 'hj'),
(5, 'Du bon rap', '2017-05-03 03:54:33', NULL, 3, 1, 3, 1, NULL, NULL, NULL, 'Hi, This is a decision'),
(6, 'My computer went down unexcepted fully. But I still get some of news of this version of software. Can you help me find a solution on that, please?', '2017-05-03 11:31:11', NULL, 2, 1, 3, 1, 'Hi, very nice, my man.', 'Hello man', 2, 'We have discovered that this is no more an issue');

-- --------------------------------------------------------

--
-- Table structure for table `TicketType`
--

CREATE TABLE IF NOT EXISTS `TicketType` (
  `idTicketType` int(11) NOT NULL,
  `typeName` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `timeAdded` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `idUser` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User`
--

INSERT INTO `User` (`idUser`, `username`, `password`, `name`, `status`) VALUES
(1, 'customer', '91ec1f9324753048c0096d036a694f86', 'Customer 1', 1),
(2, 'agent', 'b33aed8f3134996703dc39f9a7c95783', 'Agent 1', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Agent`
--
ALTER TABLE `Agent`
  ADD PRIMARY KEY (`idAgent`,`User_idUser`),
  ADD KEY `fk_Agent_User1_idx` (`User_idUser`);

--
-- Indexes for table `Buy`
--
ALTER TABLE `Buy`
  ADD PRIMARY KEY (`idBuy`,`Currency_idCurrency`,`Customer_idCustomer`),
  ADD KEY `fk_Buy_Currency1_idx` (`Currency_idCurrency`),
  ADD KEY `fk_Buy_Customer1_idx` (`Customer_idCustomer`);

--
-- Indexes for table `ChangeRate`
--
ALTER TABLE `ChangeRate`
  ADD PRIMARY KEY (`idChangeRate`,`Currency_idCurrency`),
  ADD KEY `fk_ChangeRate_Currency_idx` (`Currency_idCurrency`);

--
-- Indexes for table `Conversation`
--
ALTER TABLE `Conversation`
  ADD PRIMARY KEY (`idConversation`,`Tickets_idTickets`,`Tickets_Customer_idCustomer`),
  ADD KEY `fk_Conversation_Tickets1_idx` (`Tickets_idTickets`,`Tickets_Customer_idCustomer`);

--
-- Indexes for table `Currency`
--
ALTER TABLE `Currency`
  ADD PRIMARY KEY (`idCurrency`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`idCustomer`,`User_idUser`),
  ADD KEY `fk_Customer_User1_idx` (`User_idUser`);

--
-- Indexes for table `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`idMessage`,`Conversation_idConversation`),
  ADD KEY `fk_Message_Conversation1_idx` (`Conversation_idConversation`);

--
-- Indexes for table `ReadBy`
--
ALTER TABLE `ReadBy`
  ADD PRIMARY KEY (`idReadBy`,`Agent_idAgent`,`Message_idMessage`,`Message_Conversation_idConversation`),
  ADD KEY `fk_ReadBy_Agent1_idx` (`Agent_idAgent`),
  ADD KEY `fk_ReadBy_Message1_idx` (`Message_idMessage`,`Message_Conversation_idConversation`);

--
-- Indexes for table `Service`
--
ALTER TABLE `Service`
  ADD PRIMARY KEY (`idService`,`ServicePricing_idServicePricing`,`ServicePricing_Currency_idCurrency`),
  ADD KEY `fk_Service_ServicePricing1_idx` (`ServicePricing_idServicePricing`,`ServicePricing_Currency_idCurrency`);

--
-- Indexes for table `ServicePricing`
--
ALTER TABLE `ServicePricing`
  ADD PRIMARY KEY (`idServicePricing`,`Currency_idCurrency`),
  ADD KEY `fk_ServicePricing_Currency1_idx` (`Currency_idCurrency`);

--
-- Indexes for table `TicketAttachedFiles`
--
ALTER TABLE `TicketAttachedFiles`
  ADD PRIMARY KEY (`idTicketFiles`,`Tickets_idTickets`),
  ADD KEY `fk_TicketFiles_Tickets1_idx` (`Tickets_idTickets`);

--
-- Indexes for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  ADD PRIMARY KEY (`idTicketOfType`,`TicketType_idTicketType`,`Tickets_idTickets`),
  ADD KEY `fk_TicketOfType_TicketType1_idx` (`TicketType_idTicketType`),
  ADD KEY `fk_TicketOfType_Tickets1_idx` (`Tickets_idTickets`);

--
-- Indexes for table `Tickets`
--
ALTER TABLE `Tickets`
  ADD PRIMARY KEY (`idTickets`,`Customer_idCustomer`),
  ADD KEY `fk_Tickets_Customer1_idx` (`Customer_idCustomer`);

--
-- Indexes for table `TicketType`
--
ALTER TABLE `TicketType`
  ADD PRIMARY KEY (`idTicketType`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Agent`
--
ALTER TABLE `Agent`
  MODIFY `idAgent` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Buy`
--
ALTER TABLE `Buy`
  MODIFY `idBuy` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ChangeRate`
--
ALTER TABLE `ChangeRate`
  MODIFY `idChangeRate` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Conversation`
--
ALTER TABLE `Conversation`
  MODIFY `idConversation` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Currency`
--
ALTER TABLE `Currency`
  MODIFY `idCurrency` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Customer`
--
ALTER TABLE `Customer`
  MODIFY `idCustomer` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Message`
--
ALTER TABLE `Message`
  MODIFY `idMessage` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `ReadBy`
--
ALTER TABLE `ReadBy`
  MODIFY `idReadBy` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Service`
--
ALTER TABLE `Service`
  MODIFY `idService` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ServicePricing`
--
ALTER TABLE `ServicePricing`
  MODIFY `idServicePricing` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TicketAttachedFiles`
--
ALTER TABLE `TicketAttachedFiles`
  MODIFY `idTicketFiles` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  MODIFY `idTicketOfType` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Tickets`
--
ALTER TABLE `Tickets`
  MODIFY `idTickets` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `TicketType`
--
ALTER TABLE `TicketType`
  MODIFY `idTicketType` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  ADD CONSTRAINT `fk_TicketOfType_TicketType1` FOREIGN KEY (`TicketType_idTicketType`) REFERENCES `TicketType` (`idTicketType`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TicketOfType_Tickets1` FOREIGN KEY (`Tickets_idTickets`) REFERENCES `Tickets` (`idTickets`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
