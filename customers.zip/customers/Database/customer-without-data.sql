-- phpMyAdmin SQL Dump
-- version 4.4.15.8
-- https://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2017 at 12:58 PM
-- Server version: 5.6.31
-- PHP Version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `customer`
--

-- --------------------------------------------------------

--
-- Table structure for table `Agent`
--

CREATE TABLE IF NOT EXISTS `Agent` (
  `idAgent` int(11) NOT NULL,
  `idNumber` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Buy`
--

CREATE TABLE IF NOT EXISTS `Buy` (
  `idBuy` int(11) NOT NULL,
  `buyTime` datetime DEFAULT NULL,
  `amountPaid` varchar(45) DEFAULT NULL,
  `Currency_idCurrency` int(11) NOT NULL,
  `Customer_idCustomer` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ChangeRate`
--

CREATE TABLE IF NOT EXISTS `ChangeRate` (
  `idChangeRate` int(11) NOT NULL,
  `Currency_idCurrency` int(11) NOT NULL,
  `value` float DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Conversation`
--

CREATE TABLE IF NOT EXISTS `Conversation` (
  `idConversation` int(11) NOT NULL,
  `conversationName` varchar(45) DEFAULT NULL,
  `openingDate` datetime DEFAULT NULL,
  `Tickets_idTickets` int(11) NOT NULL,
  `Tickets_Customer_idCustomer` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Currency`
--

CREATE TABLE IF NOT EXISTS `Currency` (
  `idCurrency` int(11) NOT NULL,
  `currencyName` varchar(45) DEFAULT NULL,
  `currencySymbol` varchar(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE IF NOT EXISTS `Customer` (
  `idCustomer` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Message`
--

CREATE TABLE IF NOT EXISTS `Message` (
  `idMessage` int(11) NOT NULL,
  `content` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `Conversation_idConversation` int(11) NOT NULL,
  `senderId` int(11) DEFAULT NULL COMMENT 'The ID of the message\nsender.\nIt can be the custo\nmer or the agent',
  `senderType` int(11) DEFAULT NULL COMMENT '1 - customer\n2 - agent\n'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ReadBy`
--

CREATE TABLE IF NOT EXISTS `ReadBy` (
  `idReadBy` int(11) NOT NULL,
  `dateRead` datetime DEFAULT NULL,
  `Agent_idAgent` int(11) NOT NULL,
  `Message_idMessage` int(11) NOT NULL,
  `Message_Conversation_idConversation` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Service`
--

CREATE TABLE IF NOT EXISTS `Service` (
  `idService` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `ServicePricing_idServicePricing` int(11) NOT NULL,
  `ServicePricing_Currency_idCurrency` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ServicePricing`
--

CREATE TABLE IF NOT EXISTS `ServicePricing` (
  `idServicePricing` int(11) NOT NULL,
  `amount` float DEFAULT NULL,
  `reduction` float DEFAULT NULL,
  `additionTime` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `Currency_idCurrency` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TicketAttachedFiles`
--

CREATE TABLE IF NOT EXISTS `TicketAttachedFiles` (
  `idTicketFiles` int(11) NOT NULL,
  `fileLink` varchar(255) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `Tickets_idTickets` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TicketOfType`
--

CREATE TABLE IF NOT EXISTS `TicketOfType` (
  `idTicketOfType` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `TicketType_idTicketType` int(11) NOT NULL,
  `Tickets_idTickets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Tickets`
--

CREATE TABLE IF NOT EXISTS `Tickets` (
  `idTickets` int(11) NOT NULL,
  `content` text,
  `openingDate` datetime DEFAULT NULL,
  `closingDate` datetime DEFAULT NULL,
  `priority` int(11) DEFAULT NULL COMMENT 'Urgent\n',
  `required_service` int(11) DEFAULT NULL COMMENT 'Sales\nTechnical',
  `status` int(11) DEFAULT NULL,
  `Customer_idCustomer` int(11) NOT NULL,
  `solution` text,
  `problem_discovered` text,
  `solution_by_id_user_agent` int(11) DEFAULT NULL,
  `reason_closing` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TicketType`
--

CREATE TABLE IF NOT EXISTS `TicketType` (
  `idTicketType` int(11) NOT NULL,
  `typeName` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `timeAdded` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE IF NOT EXISTS `User` (
  `idUser` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Agent`
--
ALTER TABLE `Agent`
  ADD PRIMARY KEY (`idAgent`,`User_idUser`),
  ADD KEY `fk_Agent_User1_idx` (`User_idUser`);

--
-- Indexes for table `Buy`
--
ALTER TABLE `Buy`
  ADD PRIMARY KEY (`idBuy`,`Currency_idCurrency`,`Customer_idCustomer`),
  ADD KEY `fk_Buy_Currency1_idx` (`Currency_idCurrency`),
  ADD KEY `fk_Buy_Customer1_idx` (`Customer_idCustomer`);

--
-- Indexes for table `ChangeRate`
--
ALTER TABLE `ChangeRate`
  ADD PRIMARY KEY (`idChangeRate`,`Currency_idCurrency`),
  ADD KEY `fk_ChangeRate_Currency_idx` (`Currency_idCurrency`);

--
-- Indexes for table `Conversation`
--
ALTER TABLE `Conversation`
  ADD PRIMARY KEY (`idConversation`,`Tickets_idTickets`,`Tickets_Customer_idCustomer`),
  ADD KEY `fk_Conversation_Tickets1_idx` (`Tickets_idTickets`,`Tickets_Customer_idCustomer`);

--
-- Indexes for table `Currency`
--
ALTER TABLE `Currency`
  ADD PRIMARY KEY (`idCurrency`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`idCustomer`,`User_idUser`),
  ADD KEY `fk_Customer_User1_idx` (`User_idUser`);

--
-- Indexes for table `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`idMessage`,`Conversation_idConversation`),
  ADD KEY `fk_Message_Conversation1_idx` (`Conversation_idConversation`);

--
-- Indexes for table `ReadBy`
--
ALTER TABLE `ReadBy`
  ADD PRIMARY KEY (`idReadBy`,`Agent_idAgent`,`Message_idMessage`,`Message_Conversation_idConversation`),
  ADD KEY `fk_ReadBy_Agent1_idx` (`Agent_idAgent`),
  ADD KEY `fk_ReadBy_Message1_idx` (`Message_idMessage`,`Message_Conversation_idConversation`);

--
-- Indexes for table `Service`
--
ALTER TABLE `Service`
  ADD PRIMARY KEY (`idService`,`ServicePricing_idServicePricing`,`ServicePricing_Currency_idCurrency`),
  ADD KEY `fk_Service_ServicePricing1_idx` (`ServicePricing_idServicePricing`,`ServicePricing_Currency_idCurrency`);

--
-- Indexes for table `ServicePricing`
--
ALTER TABLE `ServicePricing`
  ADD PRIMARY KEY (`idServicePricing`,`Currency_idCurrency`),
  ADD KEY `fk_ServicePricing_Currency1_idx` (`Currency_idCurrency`);

--
-- Indexes for table `TicketAttachedFiles`
--
ALTER TABLE `TicketAttachedFiles`
  ADD PRIMARY KEY (`idTicketFiles`,`Tickets_idTickets`),
  ADD KEY `fk_TicketFiles_Tickets1_idx` (`Tickets_idTickets`);

--
-- Indexes for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  ADD PRIMARY KEY (`idTicketOfType`,`TicketType_idTicketType`,`Tickets_idTickets`),
  ADD KEY `fk_TicketOfType_TicketType1_idx` (`TicketType_idTicketType`),
  ADD KEY `fk_TicketOfType_Tickets1_idx` (`Tickets_idTickets`);

--
-- Indexes for table `Tickets`
--
ALTER TABLE `Tickets`
  ADD PRIMARY KEY (`idTickets`,`Customer_idCustomer`),
  ADD KEY `fk_Tickets_Customer1_idx` (`Customer_idCustomer`);

--
-- Indexes for table `TicketType`
--
ALTER TABLE `TicketType`
  ADD PRIMARY KEY (`idTicketType`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Agent`
--
ALTER TABLE `Agent`
  MODIFY `idAgent` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Buy`
--
ALTER TABLE `Buy`
  MODIFY `idBuy` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ChangeRate`
--
ALTER TABLE `ChangeRate`
  MODIFY `idChangeRate` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Conversation`
--
ALTER TABLE `Conversation`
  MODIFY `idConversation` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Currency`
--
ALTER TABLE `Currency`
  MODIFY `idCurrency` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Customer`
--
ALTER TABLE `Customer`
  MODIFY `idCustomer` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Message`
--
ALTER TABLE `Message`
  MODIFY `idMessage` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ReadBy`
--
ALTER TABLE `ReadBy`
  MODIFY `idReadBy` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Service`
--
ALTER TABLE `Service`
  MODIFY `idService` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ServicePricing`
--
ALTER TABLE `ServicePricing`
  MODIFY `idServicePricing` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TicketAttachedFiles`
--
ALTER TABLE `TicketAttachedFiles`
  MODIFY `idTicketFiles` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  MODIFY `idTicketOfType` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Tickets`
--
ALTER TABLE `Tickets`
  MODIFY `idTickets` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TicketType`
--
ALTER TABLE `TicketType`
  MODIFY `idTicketType` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `TicketOfType`
--
ALTER TABLE `TicketOfType`
  ADD CONSTRAINT `fk_TicketOfType_TicketType1` FOREIGN KEY (`TicketType_idTicketType`) REFERENCES `TicketType` (`idTicketType`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TicketOfType_Tickets1` FOREIGN KEY (`Tickets_idTickets`) REFERENCES `Tickets` (`idTickets`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
