<?php
	class Finance{
		/**
		 * @param nomUtilisateur string Le nom de l'utilisateur 
		 */
		public function connecter($nomUtilisateur){
			
		}
	}
