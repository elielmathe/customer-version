<?php
	class Chat{
		
	}