<?php
	class User{
		private $db_link;//Link to the database
		private $db_conn;//Connection database 
		
		public function __construct(){
			try{
				$this -> db_link = __DIR__."/../var/db.php";
				include $this -> db_link;
				$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
				$this -> db_conn = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pwd,$pdo_options);
			}catch(Exception $err){$this -> process_exception($err);}
		}
		
		public function check_username_exists($username){
			if(!empty($username)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idUser FROM User WHERE username=?");
					$query -> execute(array($username));
					if($result = $query -> fetch()){
						$query -> closeCursor();
						return true;
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function check_user_id_exists($id_user){
			if(!empty($id_user)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idUser FROM User WHERE idUser=?");
					$query -> execute(array($username));
					if($result = $query -> fetch()){
						$query -> closeCursor();
						return true;
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function save_new_user($username,$password,$name){
			if(!empty($username) and !empty($password) and !empty($name) and !($this -> check_username_exists($username))){
				try{
					$query = $this -> db_conn -> prepare("INSERT INTO User(idUser,username,password,name,status) VALUES('',?,MD5(?),?,1))");
					$query -> execute(array($username,$password,$name));
					if($result = $query -> fetch()){
						$query -> closeCursor();
						return true;
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function check_user_login($username,$password){
			if(!empty($username) and !empty($password)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idUser,name FROM User WHERE username=? and password=MD5(?)");
					$query -> execute(array($username,$password));
					if($result = $query -> fetch()){
						$type = array();
						$query -> closeCursor();
						
						$query1 = $this -> db_conn -> prepare("SELECT idCustomer FROM Customer WHERE User_idUser=?");
						$query1 -> execute(array($result['idUser']));
						if($res = $query1 -> fetch()) $type = array("type" => "customer","id_customer" => $res['idCustomer']);
						$query1 -> closeCursor();
						
						$query1 = $this -> db_conn -> prepare("SELECT idAgent FROM Agent WHERE User_idUser=?");
						$query1 -> execute(array($result['idUser']));
						if($res = $query1 -> fetch()) $type = array("type" => "agent","id_agent" => $res['idAgent']);
						$query1 -> closeCursor();
												
						return array("status" => true,"id_user" => $result['idUser'],"name" => $result['name'],"type" => $type);
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function changer_user_statuts($id_user,$new_status){
			if(!empty($id_user) and !empty($new_status)){
				try{
					$query = $this -> db_conn -> prepare("UPDATE User SET status=? WHERE idUser=?");
					$query -> execute(array($new_status,$id_user));
					if($result = $query -> fetch()){
						$query -> closeCursor();
						return true;
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function getTicketConversationId($idTicket){
			if(!empty($idTicket)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idConversation FROM Conversation WHERE Tickets_idTickets=?");
					$query -> execute(array($idTicket));
					if($res = $query -> fetch()){
						$query -> closeCursor();
						return $res['idConversation'];
					}else{
						
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function createConversation($idCustomer,$idTicket,$conversationName){
			if(!empty($idCustomer) and !empty($idTicket) and !empty($conversationName)){
				try{
					$query = $this -> db_conn -> prepare("INSERT INTO Conversation(idConversation,conversationName,openingDate,Tickets_idTickets,Tickets_Customer_idCustomer) VALUES('',?,NOW(),?,?)");
					$i = $query -> execute(array($conversationName,$idTicket,$idCustomer));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}	
			}
		}
		
		public function getMessages($idConversation){
			if(!empty($idConversation)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idMessage,content,status,creationDate,senderType FROM Message WHERE Conversation_idConversation=?");
					$query -> execute(array($idConversation));
					$to_be_returned = array();
					while($res = $query -> fetch()){
						$to_be_returned[] = $res;
					}
					$query -> closeCursor();
					return $to_be_returned;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function enregistrerMessage($idConversation,$idSender,$typeSender,$content){
			if(!empty($idConversation) and !empty($idSender) and !empty($typeSender) and !empty($content)){
				try{
					$query = $this -> db_conn -> prepare("INSERT INTO Message(idMessage,content,status,creationDate,Conversation_idConversation,senderId,senderType) VALUES('',?,1,NOW(),?,?,?)");
					$i = $query -> execute(array($content,$idConversation,$idSender,$typeSender));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		protected function process_exception($exception){
			die($exception -> getMessage());
		}
	}
