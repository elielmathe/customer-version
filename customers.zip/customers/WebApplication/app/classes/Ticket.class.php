<?php
	class Ticket{
		private $db_link;//Link to the database
		private $db_conn;//Connection database 
		
		public function __construct(){
			try{
				$this -> db_link = __DIR__."/../var/db.php";
				include $this -> db_link;
				$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
				$this -> db_conn = new PDO("mysql:host=".$host.";dbname=".$db,$user,$pwd,$pdo_options);
			}catch(Exception $err){$this -> process_exception($err);}
		}
		
		public function check_ticket_existance($id_ticket){
			if(!empty($id_ticket)){
				try{
					$query = $this -> db_conn -> prepare("SELECT idTickets FROM Tickets WHERE idTickets=?");
					$query -> execute(array($id_ticket));
					if($result = $query -> fetch()){
						$query -> closeCursor();
						return true;
					}
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function create_ticket($id_user,$content,$priority,$id_required_service){
			if(!empty($id_user) and !empty($content) and !empty($priority) and !empty($id_required_service)){
				try{
					$query = $this -> db_conn -> prepare("INSERT INTO Tickets(idTickets,content,openingDate,priority,required_service,Customer_idCustomer,status) VALUES('',?,NOW(),?,?,?,1)");
					$i = $query -> execute(array($content,$priority,$id_required_service,$id_user));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function attach_files($id_ticket,$file_link,$file_ext){
			if(!empty($id_ticket) and !empty($file_link) and !empty($file_ext) and $this -> check_ticket_existance($id_ticket) === true){
				try{
					$query = $this -> db_conn -> prepare("INSERT INTO TicketAttachedFiles(idTicketFiles,fileLink,extension,Tickets_idTickets) VALUES('',?,?,?)");
					$i = $query -> execute(array($file_ext,$file_ext,$id_ticket));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function get_tickets($id_customer){
			if(!empty($id_customer)){
				try{
					$query = $this -> db_conn -> prepare("
						SELECT 
							idTickets,content,openingDate,
							closingDate,priority,required_service,status 
						FROM Tickets 
						WHERE Customer_idCustomer=? ORDER BY status ASC,idTickets DESC");
					$query -> execute(array($id_customer));
					$to_be_returned = array();
					while($res = $query -> fetch()){
						$to_be_returned[] = $res;
					}
					$query -> closeCursor();
					return $to_be_returned;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function get_all_tickets(){
				try{
					$query = $this -> db_conn -> prepare("
						SELECT 
							idTickets,content,openingDate,
							closingDate,priority,required_service,status 
						FROM Tickets 
						ORDER BY status ASC,idTickets DESC");
					$query -> execute(array());
					$to_be_returned = array();
					while($res = $query -> fetch()){
						$to_be_returned[] = $res;
					}
					$query -> closeCursor();
					return $to_be_returned;
				}catch(Exception $err){$this -> process_exception($err);}
		}
		
		public function get_ticket_details($idTicket){
			if(!empty($idTicket)){
				try{
					$query = $this -> db_conn -> prepare("
						SELECT idTickets,Customer_idCustomer,User.name,User.username
						FROM Tickets
						INNER JOIN Customer
							ON Customer.idCustomer=Tickets.Customer_idCustomer
						INNER JOIN User
							ON User.idUser=Customer.User_idUser
						WHERE Tickets.idTickets=?
					");
					$query -> execute(array($idTicket));
					if($res = $query -> fetch()){
						$query -> closeCursor();
						return $res;
					}
					$query -> closeCursor();
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function getGraphicalInfo(){
			try{
				$query = $this -> db_conn -> prepare("
					SELECT status,COUNT(idTickets) AS nbreTickets FROM Tickets GROUP BY status
				");
				$query -> execute(array());
				$to_return = array();
				while($res = $query -> fetch()){
					$to_return[] = $res;
				}
				$query -> closeCursor();
				return $to_return;
			}catch(Exception $err){$this -> process_exception($err);}
		}
		
		/**
		* Description of below function
		* @param idAgent Integer:No table is created to save the Agent who marked on process
		* a ticket. It should added that is why there is
		*/
		public function markOnProcessTicket($idTicket,$idAgent){
			
			if(!empty($idTicket) and !empty($idAgent)){
				try{
					$query = $this -> db_conn -> prepare("
						UPDATE Tickets SET status=2 WHERE idTickets=?
					");
					$i = $query -> execute(array($idTicket));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function save_solution($idUser,$idTicket,$problem_discovered,$solution_provided){
			if(!empty($idUser) and !empty($idTicket) and !empty($problem_discovered) and !empty($solution_provided)){
				try{
					$query = $this -> db_conn -> prepare("
						UPDATE Tickets SET solution=?,problem_discovered=?,solution_by_id_user_agent=? WHERE idTickets=?
					");
					$i = $query -> execute(array($solution_provided,$problem_discovered,$idUser,$idTicket));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		public function close_ticket($idAgent,$idTicket,$reason){
			if(!empty($idAgent) and !empty($idTicket) and !empty($reason)){
				try{
					$query = $this -> db_conn -> prepare("
						UPDATE Tickets SET status=3,reason_closing=? WHERE idTickets=?
					");
					$i = $query -> execute(array($reason,$idTicket));
					$query -> closeCursor();
					if($i > 0) return true;
				}catch(Exception $err){$this -> process_exception($err);}
			}
		}
		
		protected function process_exception($exception){
			die($exception -> getMessage());
		}
	}
