<?php
	
	if(!empty($_POST)){
		if(!empty($_POST['act'])){
			if($_POST['act'] == "1"){
				session_start();
				if(!empty($_SESSION) && !empty($_SESSION['user_code'])){
					$idTicket = addslashes(htmlspecialchars($_POST['ticket']));
					include_once __DIR__."/../../app/classes/User.class.php";
					
					if($_SESSION['type_ab'] == "customer"){
						$user = new User();
						$idConversation = $user -> getTicketConversationId($idTicket);
						if($idConversation != false && $idConversation > 0){
						}else{
							$user -> createConversation($_SESSION['customer_code'], $idTicket, "Ticket_".str_pad($idTicket,5,STR_PAD_LEFT));
							$idConversation = $user -> getTicketConversationId($idTicket);
						}
												
						$content = htmlspecialchars(addslashes($_POST['msg']));
						$i = $user -> enregistrerMessage($idConversation, $_SESSION['user_code'], 1, $content);
						if($i === true){
							echo "[{'etat':'1'}]";
						}else{
							echo "[{'etat':'-2'}]";
						}												
					}else if($_SESSION['type_ab'] == "agent"){
						$user = new User();
						$idConversation = $user -> getTicketConversationId($idTicket);
						if($idConversation != false && $idConversation > 0){
						}else{
							$user -> createConversation($_SESSION['customer_code'], $idTicket, "Ticket_".str_pad($idTicket,5,STR_PAD_LEFT));
							$idConversation = $user -> getTicketConversationId($idTicket);
						}
												
						$content = htmlspecialchars(addslashes($_POST['msg']));
						$i = $user -> enregistrerMessage($idConversation, $_SESSION['user_code'], 2, $content);
						if($i === true){
							echo "[{'etat':'1'}]";
						}else{
							echo "[{'etat':'-2'}]";
						}
					}
				}
			}else if($_POST['act'] == "2"){
				session_start();
				$idTicket = htmlspecialchars($_POST['ticket']);
				
				include_once __DIR__."/../../app/classes/User.class.php";
				include_once __DIR__."/../../app/classes/Ticket.class.php";
				$user = new User();
				$ticket = new Ticket();
				
				$idConversation = $user -> getTicketConversationId($idTicket);
				if($idConversation != false && $idConversation > 0){
				}else{
					$user -> createConversation($_SESSION['customer_code'], $idTicket, "Ticket_".str_pad($idTicket,5,STR_PAD_LEFT));
					$idConversation = $user -> getTicketConversationId($idTicket);
				}
				
				$idTicket = htmlspecialchars(addslashes($_POST['ticket']));
				$messages = $user -> getMessages($idConversation);
				$ticketDetails = $ticket -> get_ticket_details($idTicket);
								
				echo '	<div class="modal-content">';
				echo '		<div class="modal-header">';
				echo '			<button type="button" data-dismiss="modal" class="btn btn-default" id="btn-fermer-popup-msg">Close</button>';
				echo '			<h4>Ticket #'.str_pad($idTicket,0,5).' - Messages</h4>';
				echo '			<div>'.$ticketDetails['name'].' - '.$ticketDetails['username'].'</div>';
				echo '		</div>';
				
				echo '		<div class="modal-body">';
				
				for($i=0;$i<count($messages);$i++){
					
					echo '			<div class="messages">';
					if($messages[$i]['senderType'] == "1"){
					echo '				<div class="one-message user-message">'.$messages[$i]['content'].'
											<div class="message-time">'.$messages[$i]['creationDate'].'</div>
										</div>';
					}else if($messages[$i]['senderType'] == "2"){
						echo '			<div class="one-message our-message">'.$messages[$i]['content'].'
											<div class="message-time">'.$messages[$i]['creationDate'].'</div>
										</div>';
					}	
					echo '			</div>';	
				}				
				echo '			<div class="input-group input-group-md">';
				echo '				<textarea class="form-control" id="champ-entree-texte" placeholder="Type in your text message"></textarea>';
				echo '				<span class="input-group-btn"><button id="btn-envoyer-message" class="btn btn-success">Send<span class="glyphicon glyphicon-menu-right"></span></button></span>';
				echo '			</div>';
				echo '		</div>';
				echo '	</div>';
				
			}
		}
	}
