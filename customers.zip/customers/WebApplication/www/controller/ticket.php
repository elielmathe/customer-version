<?php
	//print_r($_POST);
	if(!empty($_POST)){
		if(!empty($_POST['act'])){
			if($_POST['act'] == "1"){
				@session_start();
				if(!empty($_SESSION) and !empty($_SESSION['user_code'])){
					include_once __DIR__."/../../app/classes/Ticket.class.php";
					if(
						!empty($_POST['content_ticket']) and 
						!empty($_POST['date_realised']) and 
						!empty($_POST['time_realised']) and
						!empty($_POST['priority']) and 
						!empty($_POST['required_service'])
					){
						if($_POST['priority'] == "low"){
							$_POST['priority'] = 1;
						}else if($_POST['priority'] == "normal"){
							$_POST['priority'] = 2;
						}else if($_POST['priority'] == "high"){
							$_POST['priority'] = 3;
						}
						if($_POST['required_service'] == "technical"){
							$_POST['required_service'] = 1;
						}else if($_POST['required_service'] == "sales"){
							$_POST['required_service'] = 2;
						}else if($_POST['required_service'] == "administration"){
							$_POST['required_service'] = 3;
						}
						$ticket = new Ticket();
						$i = $ticket -> create_ticket($_SESSION['user_code'], $_POST['content_ticket'], $_POST['priority'], $_POST['required_service']);
						if($i === true){
							header("location:../user.ticket.zone.php?status=success");
						}else{
							header("location:../user.ticket.zone.php?status=echec");
						}
						
					}
				}
			}else if($_POST['act'] == "2"){
				include_once __DIR__."/../../app/classes/Ticket.class.php";
				$ticket = new Ticket();
				$graphical_info = $ticket -> getGraphicalInfo();
				echo "[";
				for($i=0;$i<count($graphical_info);$i++){
					if($i == 0) echo "{";
					else echo ",{";
					if($graphical_info[$i]['status'] == "1"){
						echo "label:'Opened',data:".$graphical_info[$i]['nbreTickets'].",color:'red'";
					}else if($graphical_info[$i]['status'] == "2"){
						echo "label:'Process',data:".$graphical_info[$i]['nbreTickets'].",color:'#00ffec'";
					}else if($graphical_info[$i]['status'] == "3"){
						echo "label:'Solved',data:".$graphical_info[$i]['nbreTickets'].",color:'#3edb1a'";
					}
					
					echo "}";
				}
				echo "]";
			}else if($_POST['act'] == "3"){
				@session_start();
				if(!empty($_POST['ticket'])){
					$idTicket = htmlspecialchars($_POST['ticket']);
					if(!empty($_SESSION) and $_SESSION['type_ab'] == "agent"){
						include_once __DIR__."/../../app/classes/Ticket.class.php";
						$ticket = new Ticket();
						
						if($ticket -> markOnProcessTicket($idTicket, $_SESSION['agent_code'])){
							echo "[{'etat':'1'}]";
						}else{
							echo "[{'etat':'-2'}]";
						}
					}
				}
				
			}else if($_POST['act'] == "4"){
				@session_start();
				if(!empty($_POST['ticket']) and !empty($_POST['reason'])){
					$idTicket = htmlspecialchars(addslashes($_POST['ticket']));
					$reason = htmlspecialchars(addslashes($_POST['reason']));
					
					if(!empty($_SESSION) and $_SESSION['type_ab'] == "agent"){
						include_once __DIR__."/../../app/classes/Ticket.class.php";
						$ticket = new Ticket();
						
						if($ticket -> close_ticket($_SESSION['agent_code'], $idTicket, $reason)){
							echo "[{'etat':'1'}]";
						}else{
							echo "[{'etat':'-2'}]";
						}
					}
				}
			}else if($_POST['act'] == "5"){
				if(!empty($_POST['ticket']) and !empty($_POST['problem_discovered']) and !empty($_POST['solution_provided'])){
					$idTicket = htmlspecialchars(addslashes($_POST['ticket']));
					$problemDiscovered = htmlspecialchars(addslashes($_POST['problem_discovered']));
					$solutionProvided = htmlspecialchars(addslashes($_POST['solution_provided']));
					
					@session_start();
					if(!empty($_SESSION) and $_SESSION['type_ab'] == "agent"){
						include_once __DIR__."/../../app/classes/Ticket.class.php";
						$ticket = new Ticket();
						
						if($ticket -> save_solution($_SESSION['user_code'], $idTicket, $problemDiscovered, $solutionProvided)){
							echo "[{'etat':'1'}]";
						}else{
							echo "[{'etat':'-2'}]";
						}
					}
				}
			}
		}
	}
