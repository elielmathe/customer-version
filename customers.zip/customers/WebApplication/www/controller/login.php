<?php
	if(!empty($_POST)){
		if(!empty($_POST['u']) and !empty($_POST['p'])){
			$username = htmlspecialchars(addslashes($_POST['u']));
			$password = htmlspecialchars(addslashes($_POST['p']));
			
			include_once __DIR__."/../../app/classes/User.class.php";
			
			$user = new User();
			$info = $user -> check_user_login($username, $password);
			if($info !== false && $info[status] === true){
				switch($info['type']['type']){
					case 'agent':
						@session_start();
						$_SESSION['type_ab'] = "agent";
						$_SESSION['status'] = "xEldf";
						$_SESSION['user_code'] = $info['id_user'];
						$_SESSION['agent_code'] = $info['type']['id_agent'];
						$_SESSION['name_of_user'] = $info['name'];
						header("location:../index.php");
						break;
					case 'customer':
						@session_start();
						$_SESSION['type_ab'] = "customer";
						$_SESSION['status'] = "xEldfs";
						$_SESSION['user_code'] = $info['id_user'];
						$_SESSION['customer_code'] = $info['type']['id_customer'];
						$_SESSION['name_of_user'] = $info['name'];
						header("location:../user.ticket.zone.php");
						break;	
				}
			}		
		}else{
			header("location:../login.php");
		}
	}
