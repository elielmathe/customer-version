var id_ticket_msg;
var audio_notif;
var audio_de_notification;

$(function() {
	$("#start-live-chat-user").click(function() {
		if($("#live-chat-user").is(":visible")) {
			
		} else {
			$("#live-chat-user").addClass("popup-box-on");
			
			startChat(function(server_connexion){
				$(".texte_connecting_chat").hide("fast",function(){
					$(".texte_technical_kuukha").show("fast");
					$(".popup-messages .direct-chat-messages").show("fast");
				});
				
				$("#input_btn_send_msg").unbind("click").promise().done(function(){
					$(this).click(function(){
						if($("#input_txt_msg").val() == "") return;
						server_connexion.send($("#input_txt_msg").val());
						var txtmsg = '<div class="direct-chat-msg">';
						txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-name pull-left">You</span></div>';
						txtmsg += '		<img style="background:#D7D7D7;" src="img/user.png" class="direct-chat-img">';
						txtmsg += '		<div class="direct-chat-text">' + $("#input_txt_msg").val() + '</div>';
						var laDate = new Date();
						txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-timestamp pull-right">' + laDate.getHours() + ':' + laDate.getMinutes() + '</span></div>';
						txtmsg += '	</div>';
						$(".popup-messages .direct-chat-messages").append(txtmsg);
						$("#input_txt_msg").val("");
					});
				});
				
				$("#input_txt_msg").keypress(function(e){
					if(e.keyCode == 13){
						if($("#input_txt_msg").val() == "") return;
						server_connexion.send($("#input_txt_msg").val());
						var txtmsg = '<div class="direct-chat-msg">';
						txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-name pull-left">You</span></div>';
						txtmsg += '		<img style="background:#D7D7D7;" src="img/user.png" class="direct-chat-img">';
						txtmsg += '		<div class="direct-chat-text">' + $("#input_txt_msg").val() + '</div>';
						var laDate = new Date();
						txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-timestamp pull-right">' + laDate.getHours() + ':' + laDate.getMinutes() + '</span></div>';
						txtmsg += '	</div>';
						$(".popup-messages .direct-chat-messages").append(txtmsg);
						
						$("#input_txt_msg").val("");
					}
				});
				
				server_connexion.onopen = function(){
					$(".texte_technical_kuukha").html("Technical - Kuukha");
				};
				
				//audio_notif = new Audio("sound/notif.mp3");
				audio_de_notification = new Audio("sound/notif.mp3");
				
				server_connexion.onmessage = function(e){
					audio_de_notification.play();
					var txtmsg = '<div class="direct-chat-msg">';
					txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-name pull-left">Technical - Kuukha</span></div>';
					txtmsg += '		<img style="background: white;" src="img/person.png" class="direct-chat-img">';
					txtmsg += '		<div class="direct-chat-text kuukha-msg">' + e.data + '</div>';
					var laDate = new Date();
					txtmsg += '		<div class="direct-chat-info clearfix"><span class="direct-chat-timestamp pull-right">' + laDate.getHours() + ':' + laDate.getMinutes() + '</span></div>';
					txtmsg += '	</div>';
					$(".popup-messages .direct-chat-messages").append(txtmsg);
				};
				
				server_connexion.onclose = function(){
					$(".texte_technical_kuukha").html("<h5 style='color:red;'>Connection stopped. Unable to connect.</h5>");
				};
			});
		}
	});
	
	$("#btn-close-the-chat-user").click(function(){
		if($("#live-chat-user").is(":visible")) {
			$("#live-chat-user").removeClass("popup-box-on");
		} else {
			
		}
	});
	
	$("#btn-envoyer-message").click(function(){
		if($("#champ-entree-texte").val() != ""){
			$.post("controller/message.php",{
				"msg":$("#champ-entree-texte").val(),
				"ticket":id_ticket_msg,
				"act":1
			},function(data){
				var elts = eval(data);
				if(elts && elts[0] && elts[0].etat == 1){
					$("#champ-entree-texte").val("");
				}
			});
		}
	});
	
	$(".btn-click-open-msg").click(function(){
		//$("#message-popup").css("width","80%").css("margin-left","auto").css("margin-right","auto");
		id_ticket_msg = $(this).attr("code_ticket");
		getMessages($(this).attr("code_ticket"),function(data){
			$("#message-popup").html(data).promise().done(function(){
				initBtnSendMessage();
			});
		});
	});
});

function initBtnSendMessage(){
	$("#btn-envoyer-message").unbind("click").promise().done(function(){
					$(this).click(function(){
						if($("#champ-entree-texte").val() != ""){
							$.post("controller/message.php",{
								"msg":$("#champ-entree-texte").val(),
								"ticket":id_ticket_msg,
								"act":1
							},function(data){
								getMessages(id_ticket_msg,function(data){
									$("#message-popup").html(data);
									initBtnSendMessage();
								});
								var elts = eval(data);
								if(elts && elts[0] && elts[0].etat == 1){
									$("#champ-entree-texte").val("");
								}
							});
						}
					});
	});
}

function getMessages(ticket_code,callback){
	$.post("controller/message.php",{
		"act":2,
		"ticket":ticket_code
	},function(data){
		if(typeof callback == "function") callback(data);
	});
}

var obj_chat_agent,adresse_serveur_user="ws://127.0.0.1:8080";

function startChat(callback){
	if(obj_chat_agent && obj_chat_agent.readyState == 1){
		callback(obj_chat_agent);
	}else{
		obj_chat_agent = new WebSocket(adresse_serveur_user);
		callback(obj_chat_agent);
	}
}