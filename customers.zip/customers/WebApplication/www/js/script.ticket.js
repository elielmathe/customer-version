$(function(){
	draw_graphic();	
	tinymce.init({ selector:'.wysiwyg-editor',height:200,theme:'modern'});
});

function draw_graphic(){
	get_graphic_tickets(function(data){
		var elts = eval(data);
		var options = {
			series:{
				pie:{
					show:true
				}
			}
		};
		$("#graphic-tickets").plot(elts,options);
	});
}

function get_graphic_tickets(callback){
	$.post("controller/ticket.php",{
		"act":"2"
	},function(data){
		if(typeof callback == "function") callback(data);
	});
}