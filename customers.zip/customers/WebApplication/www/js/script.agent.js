var code_ticket_close,code_ticket_solution;
var audio_notif_agent;

$(function(){
	$("#btn-ouvrir-chat-zone").click(function(){
		
		startChatAgent(function(server_connexion){	
			$("#etat_connexion_chat").css("background","orange");
					
			server_connexion.onopen = function(){
				$("#etat_connexion_chat").css("background","#13dc13");
				$("#input-chat-1").keypress(function(e){
					if(e.keyCode == 13){
						if($("#input-chat-1").val() == "") return;
						server_connexion.send($("#input-chat-1").val());
						var txt = '<div class="one-message">';
						txt += '	<div class="name-of-user">You</div>';
						txt += '	<div class="message-content">'+$("#input-chat-1").val()+'</div>';
						txt += '	<div class="msg-tools"><span class="glyphicon glyphicon-share-alt"></span></div>';
						var laDate = new Date();
						txt += '	<div class="message-time">' + laDate.getHours() + ':' + laDate.getMinutes() + '\'</div>';
						txt += '	<hr/>';
						txt += '</div>';
						$("#chatzone .zone-list-messages").append(txt);
						setTimeout(function(){
							$("#input-chat-1").val("");
						},200);
					}
				});
				
				$("#btn-send-msg-1").click(function(){	
					if($("#input-chat-1").val() == "") return;			
					server_connexion.send($("#input-chat-1").val());
					var txt = '<div class="one-message">';
					txt += '	<div class="name-of-user">You</div>';
					txt += '	<div class="message-content">'+$("#input-chat-1").val()+'</div>';
					txt += '	<div class="msg-tools"><span class="glyphicon glyphicon-share-alt"></span></div>';
					var laDate = new Date();
					txt += '	<div class="message-time">' + laDate.getHours() + ':' + laDate.getMinutes() + '\'</div>';
					txt += '	<hr/>';
					txt += '</div>';
					$("#chatzone .zone-list-messages").append(txt);
					setTimeout(function(){
						$("#input-chat-1").val("");
					},200);
				});
			};
			
			audio_notif_agent = new Audio("sound/notif.mp3");
			
			server_connexion.onmessage = function(e){
				audio_notif_agent.play();
				
				var txt = '<div class="one-message">';
				txt += '	<div class="name-of-user">Robert Tuneko</div>';
				txt += '	<div class="message-content">'+e.data+'</div>';
				txt += '	<div class="msg-tools"><span class="glyphicon glyphicon-share-alt"></span></div>';
				var laDate = new Date();
				txt += '	<div class="message-time">' + laDate.getHours() + ':' + laDate.getMinutes() + '\'</div>';
				txt += '	<hr/>';
				txt += '</div>';
				$("#chatzone .zone-list-messages").append(txt);
			};
			
			
			server_connexion.onclose = function(){
				$("#etat_connexion_chat").css("background","red");
			};
			
			
		});
	});
	
	$(".btn-click-open-msg").click(function(){
		//$("#message-popup").css("width","80%").css("margin-left","auto").css("margin-right","auto");
		id_ticket_msg = $(this).attr("code_ticket");
		getMessages($(this).attr("code_ticket"),function(data){
			$("#message-popup").html(data).promise().done(function(){
				//$(this).modal("show");
				initBtnSendMessage();
			});
		});
	});
	
	$(".btn-click-mark-process").click(function(){
		var btn = $(this);
		$.post("controller/ticket.php",{
			"ticket":$(this).attr("code_ticket"),
			"act":3
		},function(data){
			var elts = eval(data);
			if(elts && elts[0] && elts[0].etat == 1){
				btn.hide('fast',function(){
					btn.siblings(".btn-click-close-ticket").show('fast');
				});
			}
		});
	});
	
	
	$(".btn-click-close-ticket").click(function(){
		code_ticket_close = $(this).attr("code_ticket");
	});
	
	$(".btn-click-add-solution").click(function(){
		code_ticket_solution = $(this).attr("code_ticket");
	});
	
	$("#btn-close-ticket").click(function(){
		$.post("controller/ticket.php",{
			"reason":$("#closing-reason").val(),
			"ticket":code_ticket_close,
			"act":4
		},function(data){
			var elts = eval(data);
			if(elts && elts[0] && elts[0].etat == 1){
				alert("Ticket closed successfully");
				draw_graphic();
			}
		});
	});
	
	$("#btn-save-solution").click(function(){
		$.post("controller/ticket.php",{
			"problem_discovered":$("#problem_discovered").val(),
			"solution_provided":$("#solution_provided").val(),
			"ticket":code_ticket_solution,
			"act":5
		},function(data){
			var elts = eval(data);
			if(elts && elts[0] && elts[0].etat == 1){
				alert("Solution added successfully");
				draw_graphic();
			}
		});
	});
});

function initBtnSendMessage(){
	$("#btn-envoyer-message").unbind("click").promise().done(function(){
					$(this).click(function(){
						if($("#champ-entree-texte").val() != ""){
							$.post("controller/message.php",{
								"msg":$("#champ-entree-texte").val(),
								"ticket":id_ticket_msg,
								"act":1
							},function(data){
								getMessages(id_ticket_msg,function(data){
									$("#message-popup").html(data);
									initBtnSendMessage();
								});
								var elts = eval(data);
								if(elts && elts[0] && elts[0].etat == 1){
									$("#champ-entree-texte").val("");
								}
							});
						}
					});
				});
}

function getMessages(ticket_code,callback){
	$.post("controller/message.php",{
		"act":2,
		"ticket":ticket_code
	},function(data){
		if(typeof callback == "function") callback(data);
	});
}

var obj_chat_agent,adresse_serveur_agent="ws://127.0.0.1:8080";

function startChatAgent(callback){
	if(obj_chat_agent && obj_chat_agent.readyState == 1){
		callback(obj_chat_agent);
	}else{
		obj_chat_agent = new WebSocket(adresse_serveur_agent);
		callback(obj_chat_agent);
	}
}